import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ReforestRegions {
    // public ReforestRegions() {
    // reforestGhana = new ArrayList<Region>();
    // regionsOfGhana = new ArrayList<String>();
    // numberOfRegionTrees = new ArrayList<String>();
    // }

    /**
     * @param args
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {

        ArrayList<Region> regionsOfGhana = new ArrayList<>();
        String filePath = "reforestation.csv";
        File file = new File(filePath);
        Scanner scan = new Scanner(file);

        try {
            Scanner scanner = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("Error opening the file: " + file);
            System.exit(0);
        }

        while (scan.hasNextLine())
            System.out.println(scan.nextLine());
        regionsOfGhana.add(scan.next());

        // close Scanner object
        scan.close();
    }

}
